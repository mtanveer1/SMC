clear;
clc;
warning off;

Result=fopen('C:\Users\HP\OneDrive\Desktop\Result.txt','w');
% fprintf(Result,"Data Set Name          training Acc           Testing Acc    c1_best      c2_best  mu_best  Time\n");
fprintf(Result,"DataSetName\t TrainAccuracy\t TestAccuracy\t sensitivity\t specificity\t precision\t recall\t f_measure\t gmean\t tp\t tn\t fp\t fn\t TrainTime\t TestTime\t c_1\t c_2\t mu\n");

addpath(genpath('C:\..')) %Paste your path
file1=load('Data.mat'); %Data Name

[m,n] = size(file1);

%define the class level +1 or -1
for i=1:m
    if file1(i,n)==0
        file1(i,n)=-1;
    end
end
E2=[];
TestAcc=0;
NoEpoch=20;
for pp=1:NoEpoch

    cv = cvpartition(size(file1,1),'HoldOut',0.3);
    idx = cv.test;
    % Separate to training and test data
    A_train = file1(~idx,:);
    test  = file1(idx,:);

    x1 = A_train(:,1:n-1);
    y1 = A_train(:,n);

    xtest0 = test(:,1:n-1);
    ytest0 = test(:,n);
    % Normalize the data training and testing
    me=repmat(mean(x1),size(x1,1),1);
    st=repmat(std(x1),size(x1,1),1);
    tme=repmat(mean(x1),size(xtest0,1),1);
    tst=repmat(std(x1),size(xtest0,1),1);

    x1 = (x1-me)./st;
    xtest0=(xtest0-tme)./tst;

    A_test=[xtest0,ytest0];
    A_train=[x1,y1];

    C1=2.^(-5:2:5);
    C2=2.^(-5:2:5);
    mew=2.^(-10:1:10);
    Tau1=[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1];
    Tau2=[0,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1];
    BestMeanTrainAccuracy=0;
    BestMeanTestAccuracy=0;

    for i = 1:length(C1)
        FunPara.c1=C1(i);
        for j = 1:length(C2)
            FunPara.c2=C2(j);
            for k = 1:length(mew)
                FunPara.mu=mew(k)
                for l1=1:length(Tau1)
                    FunPara.tau1=Tau1(l1)
                    for l2=1:length(Tau1)
                        FunPara.tau2=Tau2(l2)

                        %%cross validation
                        no_part=5;
                        [sample_no,~]=size(A_train);
                        % tot_acc=0;
                        % t_time=0;
                        block_size = sample_no/(no_part*1.0);
                        part = 0;
                        while ceil((part+1) * block_size) <= sample_no
                            %%%%separating testing and training data points for cross validation
                            t_1 = ceil(part*block_size);
                            t_2 = ceil((part+1)*block_size);
                            Test_data = [A_train(t_1+1 :t_2 , :)];
                            Train_data = [A_train(1:t_1 , :); A_train(t_2+1:sample_no , :)];
                            %% testing and training
                            [~,EVAL_Validation,~,valid_time] = pinGTSVM(Train_data,Test_data,FunPara);

                            TempResult(part+1,:)=[EVAL_Validation,valid_time]; % Taking no
                            TempTestingAccuracy(part+1,:)=EVAL_Validation(1,1);

                            part = part+1;
                        end
                        if BestMeanTestAccuracy < mean(TempTestingAccuracy)
                            BestMeanTestAccuracy = mean(TempResult(:,1));
                            best.c1 = FunPara.c1;
                            best.c2 = FunPara.c2;
                            best.mu = FunPara.mu;
                            best.tau1 = FunPara.tau2;
                            best.tau2 = FunPara.tau2;
                        end
                        clear TempResult TempTestingAccuracy

                        if BestMeanTestAccuracy == 100
                            break
                        end
                    end
                    if BestMeanTestAccuracy == 100
                        break
                    end
                end
                if BestMeanTestAccuracy == 100
                    break
                end
            end
            if BestMeanTestAccuracy == 100
                break
            end
        end
        if BestMeanTestAccuracy == 100
            break
        end
    end
    [EVAL_Train,EVAL_Test,Train_time,Test_time]=pinGTSVM(A_train,A_test,best);

    TF = isnan(EVAL_Test);

    if sum(TF)==0 && EVAL_Test(1,1)>TestAcc

        TestAcc=EVAL_Test(1,1);
        E2=[EVAL_Train(1,1),EVAL_Test,Train_time,Test_time,best.c1,best.c2,best.mu,best.tau1,best.tau2];

    end
end
fprintf(Result,"%s\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.6f\t %0.6f\t %0.6f\t %0.6f\t %0.6f\t %0.6f\t %0.6f\t\n",Directory(u).name,E2(1,1),E2(1,2),E2(1,3),E2(1,4),E2(1,5),E2(1,6),E2(1,7),E2(1,8),E2(1,9),E2(1,10),E2(1,11),E2(1,12),E2(1,13),E2(1,14),E2(1,15),E2(1,16),E2(1,17),E2(1,18),E2(1,19));
fclose('all');
