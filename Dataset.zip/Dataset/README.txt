DATASETS:  Significant Memory Concern (SMC) V/S Healthy Control (HC)
--------------------------------------------------------------------
If you intend to use this work (dataset, code, results or any other material reltaed to our paper: Decoding Cognitive Health Using Machine Learning: A
Comprehensive Evaluation for Diagnosis of Significant Memory Concern), kindly cite us as follows:  

Reference: M. Sajid, Rahul Sharma, Iman Beheshti, and M. Tanveer “Decoding Cognitive Health Using Machine Learning: A
Comprehensive Evaluation for Diagnosis of Significant Memory Concern” WIREs Data Mining and Knowledge Discovery (2024).

The source codes of the algorithms and datasets are available at the GitHub repository https://github.com/mtanveer1/SMC.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
## Authors
----------
M. Sajid: Department of Mathematics, Indian Institute of Technology Indore, India (phd2101241003@iiti.ac.in)

Rahul Sharma: Department of Mathematics, Indian Institute of Technology Indore, India (sharmarahul.26dec@gmail.com)

Iman Beheshti: Department of Human Anatomy and Cell Science, Rady Faculty of Health Sciences, Max Rady College of Medicine, University of Manitoba, Winnipeg, MB, Canada & 
Neuroscience Research Program, Kleysen Institute for Advanced Medicine, Health Sciences Centre, Winnipeg, MB R3E 0J9, Canada (beheshtiiman@gmail.com)

M. Tanveer: Department of Mathematics, Indian Institute of Technology Indore, India (mtanveer@iiti.ac.in)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
## Datasets
-----------
Downloading and Preprocessing: The study utilized data obtained from ADNI2 (https://adni.loni.usc.edu/), which were downloaded and processed 
on November 15, 2023 by Iman Beheshti (beheshtiiman@gmail.com). 

Data Preprocessing: The CAT12 toolbox (http://www.neuro.uni-jena.de/cat/), which is an extension of the SPM12 software package, is used to 
process the structural MRI  scans in this study. The raw MRI scans underwent several preprocessing steps, including bias correction to reduce 
intensity variations and segmentation into gray matter (GM), white matter (WM), and cerebrospinal fluid (CSF) images. The DARTEL normalization 
to the Montreal Neurological Institute (MNI) space was applied (voxel size of 1.5 mm * 1.5 mm * 1.5 mm), and modulation is also employed to 
preserve volumetric information \cite{farokhian2017comparing}. Jacobian determinant (JD) images are also generated. Image quality and brain 
segmentation are visually inspected by Iman Beheshti as well as the "Check Homogeneity" feature of the CAT12 toolbox. Gaussian smoothing 
with a full width at half maximum (FWHM) of 4 mm is applied to all generated images, including GM, WM, and JD, to improve spatial coherence 
and increase the signal-to-noise ratio. Employing the Brainnetome atlas, the mean regional signals are calculated, and 273 features across 
GM, WM, and JD are obtained for each subject.  The cortical thickness (CT) measurements are also extracted based on the Desikan-Killiany-Tourville 
(DKT) atlas, comprising 68 features across the cortical area. 
Additionally, age and sex are the demographic features that are also includedin each modality's feature set.

Datasets Description: For each subject (sample), there are four modalities: cortical thinning (CT), gray matter (GM), white matter (WM), and Jacobian determinant (JD).
There are a total of 222 samples, with each class comprising 111 samples. In the dataset, each row represents the features of a single sample.

1. CT_Data: SMC V/S HC with respect to CT modality (Dimension: 222*71)
2. GM_Data: SMC V/S HC with respect to GM modality (Dimension: 222*276)
3. WM_Data: SMC V/S HC with respect to WM modality (Dimension: 222*276)
4. JD_Data: SMC V/S HC with respect to JD modality (Dimension: 222*276)
5. All_Features_Data: SMC V/S HC with respect to fusion of all features of each modality (Dimension: 222*890)

Labeling: The last column of the datasets is the label corresponding to each sample. There are two classes: 1 and -1, where 1 denotes Significant Memory Concern (SMC). 
class, and -1 denotes the Healthy Control (HC) class.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

If you have any technical queries regarding the dataset, please write to Iman Beheshti (beheshtiiman@gmail.com).

The source codes of the algorithms and datasets are available at the GitHub repository https://github.com/mtanveer1/SMC.

24-Apr-2024

