clear;
clc;

Result=fopen('C:\Users\HP\OneDrive\Desktop\Result.txt','w');
fprintf(Result,"DataSetName\t TrainAccuracy\t TestAccuracy\t sensitivity\t specificity\t precision\t recall\t f_measure\t gmean\t tp\t tn\t fp\t fn\t TrainTime\t TestTime\t Activation\t C\t N\n");

addpath(genpath('C:\..')) %Paste your path
All_data1=load('Data.mat'); %Data Name

% seed = RandStream('mcg16807','Seed',60); 
% RandStream.setGlobalStream(seed);

    [m,n]=size(All_data1);
    for i=1:m
        if All_data1(i,n)==-1
            All_data1(i,n)=0;
        end
    end

    All_X_data=zscore(All_data1(:,1:end-1)')';
    % All_X_data=rescale(All_data1(:,1:end-1));
    All_Y_data=All_data1(:,end);
    All_data2=[All_X_data,All_Y_data];  %All data

    E2=[];
    TestAcc=0;
    for pp=1:20

        %% Dataset partition-------------------1
        cv = cvpartition(size(All_data2,1),'HoldOut',0.3);
        idx = cv.test;
        % Separate to training and test data
        All_data = All_data2(~idx,:); %Only Train data
        dataTest  = All_data2(idx,:); %Only Test data

        [length_train,~] = size(All_data);
        C=[10^-8,10^-6,10^-4,10^-2,10^0,10^2,10^4,10^6,10^8];
        N=(3:20:503);
        Act=1:1:9;
        BestMeanTrainAccuracy=1;
        BestMeanTestAccuracy=1;

        no_part=5;

        for ii=1:size(C,2)
            option.C=C(1,ii)
            for jj=1:size(N,2)
                option.N=N(1,jj)
                for kk=1:size(Act,2)
                    option.activation=Act(1,kk)

                    %%Cross Validation
                    block_size = length_train/(no_part*1.0);
                    part = 0;
                    t_1 = 0;
                    t_2 = 0;

                    TempResult=[];
                    TempTestingAccuracy=zeros(1,8);

                    while ceil((part+1) * block_size) <= length_train
                        %% seprating testing and training datapoints for
                        % crossvalidation
                        if part==0
                            t_1 = ceil(part*block_size);
                            t_2 = ceil((part+1)*block_size);
                            DataTest = All_data(t_1+1 :t_2,:);
                            DataTrain = All_data(t_2+1:length_train,:);
                        elseif part==no_part-1
                            t_1 = ceil(part*block_size);
                            t_2 = ceil((part+1)*block_size);
                            DataTest = All_data(t_1+1 :t_2,:);
                            DataTrain = All_data(1:t_1,:);
                        else
                            t_1 = ceil(part*block_size);
                            t_2 = ceil((part+1)*block_size);
                            DataTest = All_data(t_1+1 :t_2,:);
                            DataTrain = [All_data(1:t_1,:); All_data(t_2+1:length_train,:)];
                        end
                        trainX=DataTrain(:,1:end-1);
                        trainY=DataTrain(:,end);
                        testX=DataTest(:,1:end-1);
                        testY=DataTest(:,end);

                        [~,EVAL_Validation,~,valid_time] = RVFL(trainX,trainY,testX,testY,option);

                        TempResult(part+1,:)=[EVAL_Validation,valid_time]; % Taking no
                        TempTestingAccuracy(part+1,:)=EVAL_Validation(1,1);
                        part = part+1;
                    end
                    if BestMeanTestAccuracy < mean(TempTestingAccuracy)
                        BestMeanTestAccuracy = mean(TempResult(:,1));
                        best.C=option.C;
                        best.N=option.N;
                        best.activation=option.activation;
                    end
                    clear TempResult TempTestingAccuracy

                    if BestMeanTestAccuracy == 100
                        break
                    end
                end
                if BestMeanTestAccuracy == 100
                    break
                end
            end
            if BestMeanTestAccuracy == 100
                break
            end
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%



        trainingX=All_data(:,1:end-1);
        trainingY=All_data(:,end);

        testingX=dataTest(:,1:end-1);
        testingY=dataTest(:,end);

        [BestModel,EVAL_Train,Train_time] = RVFL_train(trainingX,trainingY,best);

        [EVAL_Test,Test_time] = RVFL_test(testingX,testingY,BestModel,best);

        TF = isnan(EVAL_Test)

        if sum(TF)==0 && EVAL_Test(1,1)>TestAcc

            TestAcc=EVAL_Test(1,1);
            E2=[EVAL_Train(1,1),EVAL_Test,Train_time,Test_time];
        end
    end
    fprintf(Result,"%s\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %0.4f\t %d\t %d\t %d\t %d\t %0.6f\t %0.6f\t %d\t %0.6f\t %d\t\n",Directory(u).name,E2(1,1),E2(1,2),E2(1,3),E2(1,4),E2(1,5),E2(1,6),E2(1,7),E2(1,8),E2(1,9),E2(1,10),E2(1,11),E2(1,12),E2(1,13),E2(1,14),best.activation,best.C,best.N);
fclose('all');


