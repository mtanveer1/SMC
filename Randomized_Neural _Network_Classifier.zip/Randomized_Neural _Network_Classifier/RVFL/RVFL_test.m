function [EVAL_Test,test_time] = RVFL_test(X,Y,model,option)

% seed = RandStream('mcg16807','Seed',2);
% RandStream.setGlobalStream(seed);

tic
beta = model.beta;
W = model.W;
b = model.b;

Nsample = size(X,1);

activation = option.activation;
%%%%%%%%%%%%% TEST DATA %%%%%%%%%%%%%%
dataY_test=Y;
U_dataY_test = [0,1];
nclass=2;
dataY_test_temp = zeros(numel(dataY_test),nclass); %constructed a zero matrix of order [(Total no. of samples) times (No of class)]

% 0-1 coding for the target
for i=1:nclass %loop runs column wise
    idy = dataY_test==U_dataY_test(i);
    dataY_test_temp(idy,i)=1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

X1 = X*W+repmat(b,Nsample,1);

if activation == 1
    X1 = selu(X1);
elseif activation == 2
    X1 = relu(X1);
elseif activation == 3
    X1 = sigmoid(X1);
elseif activation == 4
    X1 = sin(X1);
elseif activation == 5
    X1 = hardlim(X1);        
elseif activation == 6
    X1 = tribas(X1);
elseif activation == 7
    X1 = radbas(X1);
elseif activation == 8
    X1 = sign(X1);
elseif activation == 10
    X1 = swish(X1);
elseif activation == 9
    X1 = tansig(X1);
end

X1=[X1,ones(Nsample,1)];
X = [X,X1];
% X=X1;
rawScore = X*beta;

test_time=toc;
%Accuracy Calculation
[~,ID]=max(rawScore,[],2);
Test_label=ID-1;

EVAL_Test = Evaluate(Y,Test_label);

% %softmax to generate probabilites
% rawScore_temp1 = bsxfun(@minus,rawScore,max(rawScore,[],2));
% num = exp(rawScore_temp1);
% dem = sum(num,2);
% prob_scores = bsxfun(@rdivide,num,dem);
% [~,indx] = max(prob_scores,[],2);
% [~, ind_corrClass] = max(dataY_test_temp,[],2);
% test_accuracy = mean(indx == ind_corrClass)*100;

end
%EOF
