function [model,EVAL_Train,train_time] = RVFL_train(trainX,trainY,option)

% seed = RandStream('mcg16807','Seed',2);
% RandStream.setGlobalStream(seed);

N = option.N;
C = option.C;
s = 0.1;
activation = option.activation;

[Nsample,Nfea] = size(trainX);

U_dataY_train = [0,1];
nclass=2; %Total number of class (Classification Problem)
dataY_train_temp = zeros(numel(trainY),nclass); %constructed a zero matrix of order [(Total no. of samples) times (No of class)]

% 0-1 coding for the target
for i=1:nclass %loop runs column wise
    idx = trainY==U_dataY_train(i);
    dataY_train_temp(idx,i)=1;
end

tic

% W = (rand(Nfea,N)*2*s-1);
W = (rand(Nfea,N)*2-1);
b = s*rand(1,N);
X1 = trainX*W+repmat(b,Nsample,1);

if activation == 1
    X1 = selu(X1);
elseif activation == 2
    X1 = relu(X1);
elseif activation == 3
    X1 = sigmoid(X1);
elseif activation == 4
    X1 = sin(X1);
elseif activation == 5
    X1 = hardlim(X1);        
elseif activation == 6
    X1 = tribas(X1);
elseif activation == 7
    X1 = radbas(X1);
elseif activation == 8
    X1 = sign(X1);
elseif activation == 10
    X1 = swish(X1);
elseif activation == 9
    X1 = tansig(X1);
end

X = [trainX,X1]; 
% X=X1;

X = [X,ones(Nsample,1)];%bias in the output layer

if size(X,2)<Nsample
    beta = (eye(size(X,2))*(1/C)+X'*X) \ X'*dataY_train_temp;
else
    beta = X'*((eye(size(X,1))*(1/C)+X*X') \ dataY_train_temp);
end

model.beta = beta; %output weights
model.W = W; %input-hidden layer weights
model.b = b; %hidden layer bias

trainY_temp = X*beta; %output of RVFL

train_time=toc;

%Statistical Accuracy
[~,ID]=max(trainY_temp,[],2);
Train_label=ID-1;

EVAL_Train = Evaluate(trainY,Train_label);

% %softmax to generate probabilites
% trainY_temp1 = bsxfun(@minus,trainY_temp,max(trainY_temp,[],2)); %for numerical stability
% num = exp(trainY_temp1);
% dem = sum(num,2);
% prob_scores = bsxfun(@rdivide,num,dem);
% [~,indx] = max(prob_scores,[],2);
% [~, ind_corrClass] = max(dataY_train_temp,[],2);
% train_accuracy = mean(indx == ind_corrClass)*100;

end
%EOF