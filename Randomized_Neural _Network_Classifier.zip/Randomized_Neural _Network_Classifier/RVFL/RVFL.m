function [EVAL_Train,EVAL_Validation,train_time,valid_time]  = RVFL(trainX,trainY,testX,testY,option)

% Requried for consistency
% s = RandStream('mcg16807','Seed',0);
% RandStream.setGlobalStream(s);

% Train RVFL

[Model,EVAL_Train,train_time] = RVFL_train(trainX,trainY,option);

% Using trained model, predict the testing data
[EVAL_Validation,valid_time] = RVFL_validation(testX,testY,Model,option);

end
%EOF